namespace Anarchy.StreamLibrary
{
    public enum CodecOption
    {
        RequireSameSize = 0,
        HasBuffers = 1,
        AutoDispose = 2,
        None = 3
    }
}
